﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EntityOrnek
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        DbSinavOgrenciEntities db = new DbSinavOgrenciEntities();
        private void BtnLinqEntity_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                var degerler = db.TBLNOTLAR.Where(x => x.SINAV1 < 50);
                dataGridView1.DataSource = degerler.ToList();
            }
            if (radioButton2.Checked == true)
            {
                var degerler = db.TBLOGRENCİ.Where(x => x.AD == "ali");
                dataGridView1.DataSource = degerler.ToList();
            }
            if (radioButton3.Checked == true)
            {
                var degerler = db.TBLOGRENCİ.Where(x => x.AD == textBox1.Text || x.SOYAD == textBox1.Text);
                dataGridView1.DataSource = degerler.ToList();
            }
            if (radioButton4.Checked == true)
            {
                var degerler = db.TBLOGRENCİ.Select(x => new { Soyadı = x.SOYAD });
                dataGridView1.DataSource = degerler.ToList();
            }
            if (radioButton5.Checked == true)
            {
                var degerler = db.TBLOGRENCİ.Select(x => new
                {
                    Ad = x.AD.ToUpper(),
                    Soyad = x.SOYAD.ToLower()
                });
                dataGridView1.DataSource = degerler.ToList();
            }
            if (radioButton6.Checked == true)
            {
                var degerler = db.TBLOGRENCİ.Select(x => new
                {
                    Ad = x.AD.ToUpper(),
                    Soyad = x.SOYAD.ToLower()
                }).Where(x => x.Ad != "ali");
                dataGridView1.DataSource = degerler.ToList();
            }
            if (radioButton7.Checked == true)
            {
                var degerler = db.TBLNOTLAR.Select(x => new
                {
                    OgrenciAd = x.OGR,
                    Ortalama = x.ORTALAMA,
                    Durum = x.DURUM == true ? "Geçti" : "Kaldı"
                });
                dataGridView1.DataSource = degerler.ToList();
            }
            if (radioButton8.Checked == true)
            {
                var degerler = db.TBLNOTLAR.SelectMany(x => db.TBLOGRENCİ.Where(y => y.ID == x.OGR), (x, y) => new
                {
                    y.AD,
                    y.SOYAD,
                    x.ORTALAMA
                });
                dataGridView1.DataSource = degerler.ToList();
            }
            if (radioButton9.Checked == true)
            {
                var degerler = db.TBLOGRENCİ.OrderBy(x => x.ID).Take(3);
                dataGridView1.DataSource = degerler.ToList();
            }
            if (radioButton10.Checked == true)
            {
                var degerler = db.TBLOGRENCİ.OrderByDescending(x => x.ID).Take(3);
                dataGridView1.DataSource = degerler.ToList();
            }
            if (radioButton11.Checked == true)
            {
                var degerler = db.TBLOGRENCİ.OrderBy(x => x.AD);
                dataGridView1.DataSource = degerler.ToList();
            }
            if (radioButton12.Checked == true)
            {
                var degerler = db.TBLOGRENCİ.OrderBy(x => x.ID).Skip(5);
                dataGridView1.DataSource = degerler.ToList();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var degerler = db.TBLOGRENCİ.OrderBy(x => x.SEHIR).GroupBy(y => y.SEHIR).Select(z => new
            {
                Şehir = z.Key,
                Toplam = z.Count()
            });
            dataGridView1.DataSource = degerler.ToList();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            label2.Text = db.TBLNOTLAR.Max(x => x.ORTALAMA).ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label3.Text = db.TBLNOTLAR.Min(x => x.SINAV1).ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label4.Text = db.TBLNOTLAR.Where(x => x.DURUM == false).Max(y => y.ORTALAMA).ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label5.Text = db.TBLURUN.Count().ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label6.Text = db.TBLURUN.Sum(x => x.STOK).ToString();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label7.Text = db.TBLURUN.Count(x => x.AD == "BUZDOLABI").ToString();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            label8.Text = db.TBLURUN.Average(x => x.FİYAT).ToString();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            label9.Text = db.TBLURUN.Where(x => x.AD == "BUZDOLABI").Average(y => y.FİYAT).ToString();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            label10.Text = (from i in db.TBLURUN
                            orderby i.STOK descending  //en azı isteseydik ascending kullanıcaktık
                            select i.AD).First();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = db.KULUPLER().ToList();
        }
    }
}
