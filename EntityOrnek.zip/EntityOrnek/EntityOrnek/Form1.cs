﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EntityOrnek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        DbSinavOgrenciEntities db = new DbSinavOgrenciEntities();


        private void BtnDersListesi_Click(object sender, EventArgs e)
        {
            SqlConnection _baglanti = new SqlConnection(@"Data Source=DESKTOP-GQ3I6OJ;Initial Catalog=DbSinavOgrenci;User ID=sa;Password=1");
            SqlCommand komut = new SqlCommand("Select *from TBLDERSLER", _baglanti);
            SqlDataAdapter da = new SqlDataAdapter(komut);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void BtnOgrenciListesi_Click(object sender, EventArgs e)
        {

            dataGridView1.DataSource = db.TBLOGRENCİ.ToList();
            dataGridView1.Columns[3].Visible = false;
            dataGridView1.Columns[4].Visible = false;

        }

        private void BtnNotListesi_Click(object sender, EventArgs e)
        {
            var query = from item in db.TBLNOTLAR
                        select new { item.NOTID, item.TBLOGRENCİ.AD,item.TBLOGRENCİ.SOYAD,item.TBLDERSLER.DERSAD, item.SINAV1, item.SINAV2, item.SINAV3, item.ORTALAMA, item.DURUM };
            dataGridView1.DataSource = query.ToList();
        }

        private void BtnKaydet_Click(object sender, EventArgs e)
        {
            TBLOGRENCİ t = new TBLOGRENCİ();
            t.AD = TxtAd.Text;
            t.SOYAD = TxtSoyad.Text;
            db.TBLOGRENCİ.Add(t);
            db.SaveChanges();
            MessageBox.Show("Öğrenci Listeye Eklendi");


        }

        private void BtnDersEkle_Click(object sender, EventArgs e)
        {
            TBLDERSLER d = new TBLDERSLER();
            d.DERSAD = TxtDersAd.Text;
            db.TBLDERSLER.Add(d);
            db.SaveChanges();
            MessageBox.Show("Ders Eklendi");
        }

        private void BtnSil_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(TxtOgreciID.Text);
            var x = db.TBLOGRENCİ.Find(id);
            db.TBLOGRENCİ.Remove(x);
            db.SaveChanges();
            MessageBox.Show("Silindi");
        }

        private void BtnGuncelle_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(TxtOgreciID.Text);
            var x = db.TBLOGRENCİ.Find(id);
            x.AD = TxtAd.Text;
            x.SOYAD = TxtSoyad.Text;
            x.FOTOGRAF = TxtFoto.Text;
            db.SaveChanges();
            MessageBox.Show("Öğrenci Bilgileri Başarıyla Güncellendi");

        }

        private void BtnProsedur_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = db.NOTLISTESI();
        }

        private void BtnBul_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = db.TBLOGRENCİ.Where(x => x.AD == TxtAd.Text | x.SOYAD == TxtSoyad.Text).ToList();
        }

        private void TxtAd_TextChanged(object sender, EventArgs e)
        {
            string aranan = TxtAd.Text;
            var degerler = from item in db.TBLOGRENCİ
                           where item.AD.Contains(aranan)
                           select item;
            dataGridView1.DataSource = degerler.ToList();
        }

        private void BtnLinqEntity_Click(object sender, EventArgs e)
        {
            if(radioButton1.Checked==true)
            {
                List<TBLOGRENCİ> Liste1=db.TBLOGRENCİ.OrderBy(p=>p.AD).ToList();
                dataGridView1.DataSource = Liste1;
            }
            if(radioButton2.Checked==true)
            {
                List<TBLOGRENCİ> Liste2 = db.TBLOGRENCİ.OrderByDescending(p => p.AD).ToList();
                dataGridView1.DataSource = Liste2;
            }
            if(radioButton3.Checked==true)
            {
                List<TBLOGRENCİ> Liste3 = db.TBLOGRENCİ.OrderBy(p => p.AD).Take(3).ToList();
                dataGridView1.DataSource = Liste3;
            }
            if(radioButton4.Checked==true)
            {
                List<TBLOGRENCİ> Liste4 = db.TBLOGRENCİ.Where(p => p.ID == 5).ToList();
                dataGridView1.DataSource = Liste4;
            }
            if(radioButton5.Checked==true)
            {
                List<TBLOGRENCİ> Liste5 = db.TBLOGRENCİ.Where(p => p.AD.StartsWith("a")).ToList();
                dataGridView1.DataSource = Liste5;
            }
            if(radioButton6.Checked==true)
            {
                List<TBLOGRENCİ> Liste6 = db.TBLOGRENCİ.Where(p => p.AD.EndsWith("a")).ToList();
                dataGridView1.DataSource = Liste6;
            }
            if(radioButton7.Checked==true)
            {
                bool deger = db.TBLDERSLER.Any();
                MessageBox.Show(deger.ToString(), "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if(radioButton8.Checked==true)
            {
                int toplam = db.TBLOGRENCİ.Count();
                MessageBox.Show(toplam.ToString(), "Toplam Öğrenci Sayısı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if(radioButton9.Checked==true)
            {
                var toplam = db.TBLNOTLAR.Sum(p => p.SINAV1);
                MessageBox.Show("Toplam Sınav1 Puanı: " + toplam.ToString());
            }
            if(radioButton10.Checked==true)
            {
                var ortalama = db.TBLNOTLAR.Average(p => p.SINAV1);
                MessageBox.Show("1.Sınavın Ortalaması: " + ortalama.ToString());
            }
            if(radioButton11.Checked==true)
            {
                var ortalama = db.TBLNOTLAR.Average(p => p.SINAV1);
                List<TBLNOTLAR> Liste7 = db.TBLNOTLAR.Where(p => p.SINAV1 > ortalama).ToList();
                dataGridView1.DataSource = Liste7;
            }
            if(radioButton12.Checked==true)
            {
                var enyüksek = db.TBLNOTLAR.Max(p => p.SINAV1);
                MessageBox.Show("En Yüksek Sınav1 Notu: " + enyüksek);
            }
            if (radioButton13.Checked == true)
            {
                var endüsük = db.TBLNOTLAR.Max(p => p.SINAV1);
                MessageBox.Show("En Düşük Sınav1 Notu: " + endüsük);
            }
            if (radioButton14.Checked == true)
            {
                var enyüksek = db.TBLNOTLAR.Max(p => p.SINAV1);
                dataGridView1.DataSource = db.NOTLISTESI().Where(p => p.SINAV1 == enyüksek).ToList();
            }
        }

        private void BtnJoin_Click(object sender, EventArgs e)
        {
            var sorgu = from d1 in db.TBLNOTLAR
                        join d2 in db.TBLOGRENCİ
                        on d1.OGR equals d2.ID
                        join d3 in db.TBLDERSLER
                        on d1.DERS equals d3.DERSID
                        select new
                        {
                            ögrenci=d2.AD+" "+d2.SOYAD,
                            ders=d3.DERSAD,
                            sınav1=d1.SINAV1,
                            sınav2=d1.SINAV2,
                            sınav3=d1.SINAV3,
                            ortalama=d1.ORTALAMA
                        };
            dataGridView1.DataSource = sorgu.ToList();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
